package com.wipro.eb.main;

import java.util.Scanner;

import com.wipro.eb.service.*;

public class EBMain {

	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		ConnectionService cs = new ConnectionService();
		int currentReading = sc.nextInt();
		int previousReading = sc.nextInt();
		String type = sc.next();
		System.out.println(cs.generateBill(currentReading, previousReading, type));
	}
}
