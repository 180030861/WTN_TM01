package com.wipro.eb.service;

import com.wipro.eb.exception.*;
import com.wipro.eb.entity.*;

public class ConnectionService 
{
	float[] slabs1 = {2.3f,4.2f,5.5f};
	float[] slabs2 = {5.2f,6.8f,8.3f};
	
	public boolean validate(int currentReading, int previousReading, String type) throws InvalidReadingException, InvalidConnectionException
	{
		if(currentReading < previousReading || previousReading < 0 || currentReading < 0) throw new InvalidReadingException();
		else if(!(type.equals("Domestic") || type.equals("Commercial"))) throw new InvalidConnectionException();
		else return true;
	}
	@SuppressWarnings("finally")
	public float calculateBillAmt(int currentReading, int previousReading, String type)
	{
		ConnectionService cs = new ConnectionService();
		try {
			cs.validate(currentReading, previousReading, type);
		} catch (InvalidReadingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		} catch (InvalidConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -2;
		}
		finally
		{
			float amount=0;
			if(type.equals("Domestic"))
			{
				Domestic d  = new Domestic(currentReading, previousReading, slabs1);
				amount = d.computeBill();
			}
			else 
			{
				Commercial c = new Commercial(previousReading, previousReading, slabs2);
				amount = c.computeBill();
			}
			return amount;
		}
	}
	public String generateBill(int currentReading, int previousReading, String type)
	{
		ConnectionService cs = new ConnectionService();
		float res = cs.calculateBillAmt(currentReading, previousReading, type);
		if(res == -1) return "Incorrect Reading";
		else if(res==-2)  return "Invalid Connection Type";
		else return ("Amount to be paid: "+res);
	}
}
