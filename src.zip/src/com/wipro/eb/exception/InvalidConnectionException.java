package com.wipro.eb.exception;

public class InvalidConnectionException extends Throwable {

	public String toString()
	{
		return "Invalid Connection Type";
	}
}
