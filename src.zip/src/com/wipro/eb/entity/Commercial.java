package com.wipro.eb.entity;

public class Commercial extends Connection{

	
	public Commercial(int currentReading, int previousReading, float[] slabs)
	{
		super(currentReading, previousReading, slabs);
	}

	@Override
	public float computeBill() {
		// TODO Auto-generated method stub
		float amt =0;
		amt = 50*slabs[0] + 50*slabs[1] + (currentReading-100)*slabs[2];
		if(amt < 5000) return (float) (amt+amt*0.02);
		else if(amt >= 5000) return (float) (amt+amt*0.06);
		else return (float) (amt+amt*0.09);
	}
}
