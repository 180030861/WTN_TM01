package com.wipro.eb.entity;

public class Domestic extends Connection 
{
	
	public Domestic(int currentReading, int previousReading, float[] slabs) 
	{
		super(currentReading, previousReading, slabs);
		// TODO Auto-generated constructor stub
	}
	public float computeBill()
	{
		return 50*slabs[0] + 50*slabs[1] + (currentReading-100)*slabs[2];
	}
}
