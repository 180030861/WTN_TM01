package com.wipro.eb.entity;

public abstract class Connection {

	int previousReading; // previous month reading
	int currentReading; // current month reading
	float[] slabs; // stores different slab rates
	public Connection(int currentReading, int previousReading,float slabs[]) 
	{
		this.currentReading = currentReading;
		this.previousReading = previousReading;
		this.slabs = slabs;
	} 			
	public abstract float computeBill();
	public void setCurrentReading(int currentReading)
	{
		this.currentReading = currentReading;
	}
	public int getCurrentReading()
	{
		return currentReading;
	}
	public void setPreviousReading(int previousReading)
	{
		this.previousReading = previousReading;
	}
	public int getPreviousReading()
	{
		return previousReading;
	}
}
